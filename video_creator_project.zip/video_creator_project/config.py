import os

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")
SUPPORTED_LANGUAGES = set()  # Will be populated in language_utils.py