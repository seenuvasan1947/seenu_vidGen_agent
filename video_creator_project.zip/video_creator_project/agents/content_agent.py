import google.generativeai as genai
from config import GEMINI_API_KEY

class ContentAgent:
    def __init__(self):
        genai.configure(api_key=GEMINI_API_KEY)
        self.model = genai.GenerativeModel('gemini-pro')

    def generate_content(self, topic, duration):
        prompt = f"Provide detailed information about the topic or book: '{topic}'. Include key points, interesting facts, and a suggested structure for a {duration}-minute video."
        return self.generate_response_and_image_description(prompt)

    def generate_response_and_image_description(self, prompt):
        full_prompt = f"""{prompt}

        Additionally, provide a single sentence in English that describes an image that would be suitable for this content. Separate the main content and the image description with a line of 10 dashes (----------).

        Main content:"""
        response = self.model.generate_content(full_prompt)
        content, image_desc = response.text.split('----------')
        return content.strip(), image_desc.strip()